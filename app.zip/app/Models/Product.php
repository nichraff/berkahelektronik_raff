// app/Models/Product.php
<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'kategori', 
        'brand', 
        'judul', // Nama kolom baru
        'model', 
        'harga', 
        'diskon', 
        'garansi', 
        'detail', // Nama kolom baru
        'image'
    ];
}